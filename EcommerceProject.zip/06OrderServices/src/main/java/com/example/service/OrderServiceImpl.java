package com.example.service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.client.NotificationClient;
import com.example.client.ProductClient;
import com.example.client.UserServiceClient;
import com.example.dto.NotificationDto;
import com.example.dto.OrderDto;
import com.example.dto.ProductDto;
import com.example.dto.UserDto;
import com.example.entity.Order;
import com.example.entity.OrderItem;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.OrderRepository;


@Service
public class OrderServiceImpl implements OrderServices {

	@Autowired
	private OrderRepository orderRepository;

//	@Autowired
//	private OrderItemRepository itemRepository;

	
	@Autowired
	private ModelMapper mapper;

	@Autowired
	private UserServiceClient userServiceClient;
	
	@Autowired
	private ProductClient productClient;

	@Autowired
	private NotificationClient client;

	@Override
	public OrderDto addOrder(Order dto) {
	    try {
	        UserDto userDto;
	        try {
	            userDto = userServiceClient.getUserById(dto.getUserId());
	        } catch (Exception e) {
	            throw new RuntimeException("User not found with ID: " + dto.getUserId());
	        }

	        // Initialize Order entity
	        Order order = new Order();
	        order.setUserId(dto.getUserId());
	        order.setOrderStatus(dto.getOrderStatus());
	        order.setPaymentStatus(dto.getPaymentStatus());
	        order.setBillAddress(dto.getBillAddress());
	        order.setBillingPhone(dto.getBillingPhone());
	        order.setOrderDate(LocalDate.now());
	        order.setDeliveredDate(LocalDate.now().plusDays(5));

	        double totalAmount = 0.0;

	        // Process order items
	        for (OrderItem itemRequest : dto.getOrderItems()) {
	            ProductDto product;
	            try {
	                product = productClient.getProductById(itemRequest.getProductId());
	            } catch (Exception e) {
	                throw new ResourceNotFoundException("Product","id",  itemRequest.getProductId());
	            }

	            if (product != null) {
	                OrderItem orderItem = new OrderItem();
	                orderItem.setProductId(itemRequest.getProductId());
	                orderItem.setQuantity(itemRequest.getQuantity());
	                orderItem.setTotalPrice(product.getProductPrice() * itemRequest.getQuantity());
	                orderItem.setProduct(product.getProductTitle());

	                order.addOrderItem(orderItem);
	                totalAmount += orderItem.getTotalPrice();
	            }
	        }

	        // Set total amount
	        order.setOrderAmount(totalAmount);

	        // Save order to the database
	        Order savedOrder;
	        try {
	            savedOrder = orderRepository.save(order);
	        } catch (Exception e) {
	            throw new RuntimeException("Failed to save the order: " + e.getMessage());
	        }

	        // Send notification
	        NotificationDto notificationDto = new NotificationDto();
	        notificationDto.setRecipientId(userDto.getEmail());
	        notificationDto.setContent(
	                "Dear " + userDto.getName() + "," +
	                        " Your order has been placed successfully with OrderId: " + order.getOrderId() + "," +
	                        "\n Thanks for shopping!"
	        );
	        notificationDto.setNotificationType("EMAIL");

	        try {
	            client.SendEmailNotification(notificationDto);
	        } catch (Exception e) {
	            // Log the failure but do not throw it since the order is already placed
	            System.err.println("Failed to send notification: " + e.getMessage());
	        }

	        // Return the saved order as a DTO
	        return mapToDto(savedOrder);

	    } catch (Exception e) {
	        throw new RuntimeException("Failed to process the order: " + e.getMessage());
	    }
	}


	@Override
	public List<OrderDto> orders() {
	    // Retrieve all orders and map them to DTOs
	    List<Order> orders = orderRepository.findAll();
	    return orders.stream().map(this::mapToDto).collect(Collectors.toList());
	}

	@Override
	public void delete(Long orderId) {
	    // Check if the order exists before deleting
	    if (!orderRepository.existsById(orderId)) {
	        throw new ResourceNotFoundException("Order","id", orderId);
	    }
	    orderRepository.deleteById(orderId);
	}

	@Override
	public OrderDto getOrderById(Long orderId) {
	    // Retrieve the order by ID or throw an exception if not found
	    Order order = orderRepository.findById(orderId)
	            .orElseThrow(() -> new ResourceNotFoundException("Order","id", orderId));
	    return mapToDto(order);
	}

	private OrderDto mapToDto(Order order) {
		OrderDto map1 = mapper.map(order, OrderDto.class);
		return map1;

	}

}
