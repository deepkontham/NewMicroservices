package com.example.model;

import java.time.LocalDateTime;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Notification {

	
    @Id
    private String id;
    private String content;
    private String recipientId;  
    private String subject;
    private boolean read;
    private LocalDateTime timestamp = LocalDateTime.now();
    private String notificationType; 
    private String link;
    
	
    
}


