package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.dto.NotificationDto;
import com.example.model.Notification;
//import com.example.repository.NotificationRepository;

@Service
public class NotificationService {
	
//	@Autowired
//	private NotificationRepository notificationRepository;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	public NotificationDto SendEmailNotification(Notification notification) {
//
		
				Notification no=new Notification();
//		no.setContent(notification.getContent());
//		notification.setRecipientId(notification.getRecipientId());
//        notification.setRead(false);
//        notification.setTimestamp(notification.now());
//        notification.setNotificationType("EMAIL");
//        notification.setLink(notification.getLink());
//		notificationRepository.save(no);
		SimpleMailMessage mailMessage=new SimpleMailMessage();
		mailMessage.setTo(notification.getRecipientId());
		mailMessage.setSubject(notification.getSubject());
		mailMessage.setText(notification.getContent());
		javaMailSender.send(mailMessage);
		return mapToDto(notification);
		
		
	}
	
	
	private NotificationDto mapToDto(Notification notification) {
		NotificationDto dto = new NotificationDto();
	        dto.setContent(notification.getContent());
	        dto.setRecipientId(notification.getRecipientId());
	        dto.setRead(notification.isRead());
	        dto.setNotificationType(notification.getNotificationType());
	        dto.setLink(notification.getLink());
	        return dto;
	}
	
	

}
