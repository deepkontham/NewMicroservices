package com.microservices.product.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "products")
public class Product {

	    @Id
	    private String productId;
	    private String title;
	    private String description;
	    private double basePrice;
	    private double discountedPrice;
	    private float discountPercentage;
	    private int quantity;
	    private LocalDate addedDate;
	    private boolean live;
	    private boolean stock;
	    private String productImage;
	    
	    @ManyToOne
	    @JoinColumn(name = "category_id")
	    private Category category;

	   
}
