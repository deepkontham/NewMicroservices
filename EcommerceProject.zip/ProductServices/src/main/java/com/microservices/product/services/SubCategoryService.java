package com.microservices.product.services;

import com.microservices.product.dtos.SubCategoryDto;

public interface SubCategoryService {
	
	  //create
//    SubCategoryDto create(SubCategoryDto subCategoryDto);

    //update
    SubCategoryDto update(SubCategoryDto subCategoryDto, String subCategoryId);

    //delete
    void delete(String subCategoryId);

    //get all
//    PageableResponse<SubCategoryDto> getAll(int pageNumber, int pageSize, String sortBy, String sortDir);

    //get single category detail
    SubCategoryDto get(String subCategoryId);


	SubCategoryDto create(SubCategoryDto subCategoryDto);

}
