package com.microservices.product.repositories;

import com.microservices.product.dtos.ProductDto;

import com.microservices.product.entities.Category;
import com.microservices.product.entities.Product;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product,String> {

	
    //search
    Product findByTitleContaining(String subtitle);
    Page<ProductDto> findByLiveTrue(Pageable pageable);
    @Query("SELECT p FROM Product p WHERE p.category.categoryId = :categoryId")
    Page<Product> findProductsByCategoryId(@Param("categoryId") String categoryId, Pageable pageable);
//    List<ProductDto> findBySubCategory(SubCategory subCategory);
    
    @Query("SELECT p FROM Product p WHERE p.category.title = :title")
    Page<Product> findProductsByCategoryTitle(@Param("title") String title, Pageable pageable);

}
  