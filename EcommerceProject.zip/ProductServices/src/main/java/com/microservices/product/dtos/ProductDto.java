package com.microservices.product.dtos;

import com.microservices.product.entities.Category;


import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ProductDto {


	private String productId;
    private String title;
    private String description;
    private double basePrice;
    private double discountedPrice;
    private float discountPercentage;
    private int quantity;
    private boolean live;
    private boolean stock;
    private String productImage;
    
    private String categoryId; // ID for category
//    private String subCategoryId;
//    private CategoryDto category;
//    private SubCategoryDto subCategory;

    
    

}
