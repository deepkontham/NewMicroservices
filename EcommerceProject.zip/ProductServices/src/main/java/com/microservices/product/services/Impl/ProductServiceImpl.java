package com.microservices.product.services.Impl;

import com.microservices.product.dtos.PageableResponse;


import com.microservices.product.dtos.ProductDto;
import com.microservices.product.entities.Category;
import com.microservices.product.entities.Product;
import com.microservices.product.exception.ResourceNotFoundException;
import com.microservices.product.helper.Helper;
import com.microservices.product.repositories.CategoryRepository;
import com.microservices.product.repositories.ProductRepository;
import com.microservices.product.services.ProductService;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CategoryRepository categoryRepository;

	

//    private Logger logger= LoggerFactory.getLogger(ProductServiceImpl.class);

	@Override
	public ProductDto create(ProductDto productDto) {
		Product product = new Product();

		product.setProductId(UUID.randomUUID().toString());
		product.setTitle(productDto.getTitle());
		product.setDescription(productDto.getDescription());
		product.setBasePrice(productDto.getBasePrice());
		product.setDiscountPercentage(productDto.getDiscountPercentage());
		product.setQuantity(productDto.getQuantity());
		product.setProductImage(productDto.getProductImage());

		int quantity = productDto.getQuantity();
		product.setStock(quantity > 0); // Stock is true if quantity > 0
		product.setLive(quantity > 0); // Live is true if stock is true

		product.setAddedDate(LocalDate.now());

		// Fetch and associate Category
		if (productDto.getCategoryId() != null) {
			Category category = categoryRepository.findById(productDto.getCategoryId()).orElseThrow(
					() -> new RuntimeException("Category not found with ID: " + productDto.getCategoryId()));
			product.setCategory(category);
		}

		// Fetch and associate SubCategory
//		if (productDto.getSubCategoryId() != null) {
//			SubCategory subCategory = subCategoryRepository.findById(productDto.getSubCategoryId()).orElseThrow(
//					() -> new RuntimeException("SubCategory not found with ID: " + productDto.getSubCategoryId()));
//			product.setSubCategory(subCategory);
//		}

		// Calculate discounted price
		double basePrice = product.getBasePrice();
		double discountedPrice = basePrice - (basePrice * (productDto.getDiscountPercentage() / 100));
		product.setDiscountedPrice(discountedPrice);

		// Save product to the database
		Product savedProduct = productRepository.save(product);

		// Map Entity back to DTO
		ProductDto responseDto = new ProductDto();
		responseDto.setProductId(savedProduct.getProductId());
		responseDto.setTitle(savedProduct.getTitle());
		responseDto.setDescription(savedProduct.getDescription());
		responseDto.setBasePrice(savedProduct.getBasePrice());
		responseDto.setDiscountedPrice(savedProduct.getDiscountedPrice());
		responseDto.setDiscountPercentage(savedProduct.getDiscountPercentage());
		responseDto.setQuantity(savedProduct.getQuantity());
		responseDto.setLive(savedProduct.isLive());
		responseDto.setStock(savedProduct.isStock());
		responseDto.setProductImage(savedProduct.getProductImage());

		// Map Category and SubCategory IDs
		if (savedProduct.getCategory() != null) {
			responseDto.setCategoryId(savedProduct.getCategory().getCategoryId());
		}
//		if (savedProduct.getSubCategory() != null) {
//			responseDto.setSubCategoryId(savedProduct.getSubCategory().getSubCategoryId());
//		}

		return responseDto;
	}

	private ProductDto mapToDto(Product product) {
		ProductDto map = modelMapper.map(product, ProductDto.class);
		return map;
	}

	private Product mapToEntity(ProductDto productDto) {
		Product map1 = modelMapper.map(productDto, Product.class);
		return map1;
	}

	@Override
	public ProductDto update(ProductDto productDto, String id) {
		// Fetch the product by ID
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));

		// Update the product fields from the DTO
		product.setTitle(productDto.getTitle());
		product.setDescription(productDto.getDescription());
		product.setBasePrice(productDto.getBasePrice());
		product.setDiscountPercentage(productDto.getDiscountPercentage()); // Make sure this is set correctly
		product.setQuantity(productDto.getQuantity());
		product.setProductImage(productDto.getProductImage());

		// Calculate discounted price based on the updated discount percentage
		double basePrice = product.getBasePrice();
		double discountPercentage = productDto.getDiscountPercentage();
		double discountedPrice = basePrice - (basePrice * (discountPercentage / 100));
		product.setDiscountedPrice(discountedPrice);

		// Set stock and live status
		product.setStock(productDto.getQuantity() > 0); // Stock is true if quantity > 0
		product.setLive(productDto.getQuantity() > 0); // Live is true if quantity > 0

		// Update category association
		if (productDto.getCategoryId() != null) {
			Category category = categoryRepository.findById(productDto.getCategoryId())
					.orElseThrow(() -> new ResourceNotFoundException("Category", "id", productDto.getCategoryId()));
			product.setCategory(category);
		}

		// Save the updated product entity
		Product updatedProduct = productRepository.save(product);

		// Map the updated product back to DTO and return
		return mapToDto(updatedProduct);
	}

	@Override
	public void delete(String productId) {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

//        //delete user profile image
//        String fullPath=imagePath + product.getProductImageName();
//        try
//        {
//            Path path= Paths.get(fullPath);
//            Files.delete(path);
//        }
//        catch(NoSuchFileException ex)
//        {
//            logger.info("User Image not found in folder ");
//            ex.printStackTrace();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
		productRepository.delete(product);

	}

	@Override
	public ProductDto getById(String productId) {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));

		return modelMapper.map(product, ProductDto.class);
	}

	@Override
	public PageableResponse<ProductDto> getAll(int pageNumber, int pageSize, String sortBy, String sortDir) {
		// Validate sort direction
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();

		// Create pageable object
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		// Fetch paginated data
		Page<Product> page = productRepository.findAll(pageable);

		// Convert Page<Product> to PageableResponse<ProductDto>
		return Helper.getPageableResponse(page, ProductDto.class);
	}

	@Override
	public PageableResponse<ProductDto> getAllLive(int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<ProductDto> page = productRepository.findByLiveTrue(pageable);
		return Helper.getPageableResponse(page, ProductDto.class);
	}

	@Override
	public ProductDto searchByTitle(String subTitle) {

		Product page = productRepository.findByTitleContaining(subTitle);
		if (page == null) {
			throw new ResourceNotFoundException("Title", "name", subTitle);
		}
		return modelMapper.map(page, ProductDto.class);
	}

//	@Override
//	public ProductDto createWithCategory(ProductDto productDto, String categoryId) {
//
//		// fetch the category from database
//		Category category = categoryRepository.findById(categoryId)
//				.orElseThrow(() -> new RuntimeException("Category not found"));
//		Product product = modelMapper.map(productDto, Product.class);
//
//		// product Id
//		String productId = UUID.randomUUID().toString();
//		product.setProductId(productId);
//
//		// added
//		product.setAddedDate(LocalDate.now());
//		product.setCategory(category);
//		Product saveProduct = productRepository.save(product);
//		return modelMapper.map(saveProduct, ProductDto.class);
//	}

	@Override
	public ProductDto updateCategory(String productId, String categoryId) {
		// product fetch
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));
		Category category = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Category", " id", categoryId));
		product.setCategory(category);
		Product savedProduct = productRepository.save(product);

		return modelMapper.map(savedProduct, ProductDto.class);
	}

	@Override
	public PageableResponse<ProductDto> getproductsByCategory(String categoryId, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Category category = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Category", " id", categoryId));
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Product> page = productRepository.findProductsByCategoryId(categoryId, pageable);
		if (page == null) {
			throw new ResourceNotFoundException("Title", "name", categoryId);
		}
		return Helper.getPageableResponse(page, ProductDto.class);

	}

	@Override
	public PageableResponse<ProductDto> getproductsByCategoryTitle(String title, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Category category = categoryRepository.findByTitle(title);
		if (category == null) {
			throw new ResourceNotFoundException("Title", "name", title);
		}
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Product> page = productRepository.findProductsByCategoryTitle(title, pageable);
		if (page == null) {
			throw new ResourceNotFoundException("product", "name", title);
		}
		return Helper.getPageableResponse(page, ProductDto.class);

	}
}
