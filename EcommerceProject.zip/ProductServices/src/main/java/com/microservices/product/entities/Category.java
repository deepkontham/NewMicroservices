package com.microservices.product.entities;

import jakarta.persistence.*;

import lombok.*;


import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "categories")
@Entity
public class Category {

        @Id
	    private String categoryId;
	    
	    @Column(name = "title", length = 70, nullable = false)
	    private String title;

	    @Column(name = "description", length = 500)
	    private String description;

	    @Column(name = "cover_image")
	    private String coverImage;

	    
	    
	    @OneToMany(mappedBy = "category")
	    private List<Product> products;
    
}