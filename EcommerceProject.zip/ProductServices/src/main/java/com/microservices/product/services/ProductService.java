package com.microservices.product.services;

import com.microservices.product.dtos.PageableResponse;
import com.microservices.product.dtos.ProductDto;

public interface ProductService {

    //create
    ProductDto create(ProductDto productDto);

    //update
    ProductDto update(ProductDto productDto,String id);

    //delete
    void delete(String productId);

   

    //get all
    PageableResponse<ProductDto> getAll(int pageNumber, int pageSize, String sortBy, String sortDir);



    //get all: live
    PageableResponse<ProductDto> getAllLive(int pageNumber,int pageSize,String sortBy,String sortDir);


    //search product
    ProductDto searchByTitle(String subTitle);

//    //create products with category
//    ProductDto createWithCategory(ProductDto productDto,String categoryId);

    //update category of products
    ProductDto updateCategory(String productId,String categoryId);

    PageableResponse<ProductDto> getproductsByCategory(String categoryId,int pageNumber,int pageSize,String sortBy,String sortDir);

    
    PageableResponse<ProductDto> getproductsByCategoryTitle(String categoryTitle,int pageNumber,int pageSize,String sortBy,String sortDir);

	ProductDto getById(String productId);


}
